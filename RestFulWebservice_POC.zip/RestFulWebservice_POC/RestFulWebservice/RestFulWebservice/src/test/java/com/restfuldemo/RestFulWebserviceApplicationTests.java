package com.restfuldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFulWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
