package com.restfuldemo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.omg.CosNaming.NamingContextPackage.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restfuldemo.model.Message;
import com.restfuldemo.service.MessageService;

@RestController
@RequestMapping("/restfulDemo")
public class RestfulWebserviceController {

	private static final Logger log = LoggerFactory.getLogger(RestfulWebserviceController.class);
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Autowired
	private MessageService messageService;

	@RequestMapping(method = RequestMethod.POST, value = "/addMessage")
	public ResponseEntity<Object> addMessage(@RequestBody Message mes) {

		if (((mes.getMessageSchedule() != null) && (!mes.getMessageSchedule().isEmpty()))
				&& ((mes.getMessageContent() != null) && (!mes.getMessageContent().isEmpty()))) {
			messageService.addMessage(mes);
		} else {
			return new ResponseEntity<Object>("Message Content or MessageSchedule value is null ",
					HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<Object>("Message Added Sucessfully ", HttpStatus.ACCEPTED);

	}

	@RequestMapping("/getMessage")
	public List<Message> getAllMessages() {
		return messageService.getAllMessages();
	}

	// Message Execution Scheduler
	@Scheduled(cron = "${spring.quartz.scheduler-name}")
	public void messageExecutionScheduler() {

		List<Message> mesList = messageService.getAllMessages();

		for (Message list : mesList) {
			if (list.getMessageSchedule() != null) {
				if (list.getMessageSchedule().equals(dateFormat.format(new Date()))) {
					log.info("Message Content:  " +list.getMessageContent());
					log.info("Message Schedule Time: "+list.getMessageSchedule());
				}
			}
		}

	}

}
