package com.restfuldemo.repository;

import org.springframework.data.repository.CrudRepository;

import com.restfuldemo.model.Message;

public interface MessageRepository extends CrudRepository<Message, Integer> {

}
