package com.restfuldemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restfuldemo.model.Message;
import com.restfuldemo.repository.MessageRepository;

@Service
public class MessageService {

	@Autowired
	private MessageRepository messageRepository;

	public void addMessage(Message mes) {
		messageRepository.save(mes);

	}

	public List<Message> getAllMessages() {
		List<Message> list = (List<Message>) messageRepository.findAll();
		return list;
	}

}
